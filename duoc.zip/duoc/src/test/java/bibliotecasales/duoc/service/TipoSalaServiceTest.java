package bibliotecasales.duoc.service;

import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bibliotecasales.duoc.repository.TipoSalaRepository;

@ExtendWith(MockitoExtension.class)
public class TipoSalaServiceTest {
    @Mock
    private TipoSalaRepository repository;

    @InjectMocks
    private TipoSalaService service;

}
