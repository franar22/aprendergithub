package bibliotecasales.duoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuocApplicationTests {

	@Test
	void contextLoads() {
	}

}
