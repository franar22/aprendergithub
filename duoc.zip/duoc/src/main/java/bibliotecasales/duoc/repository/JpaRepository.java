package bibliotecasales.duoc.repository;

public class JpaRepository<T1, T2> {

}
