package bibliotecasales.duoc.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@Table(name = "reserva")
@AllArgsConstructor
@NoArgsConstructor

public class Reserva {
    @Id
    private Long id;
    @Column(nullable = false)
    private Date fechaSolicitada;
    @Column(nullable = false)
    private Date horaSolicitada;
    @Column(nullable = false)
    private Date horaCierre;
    @Column(nullable = false)
    private Integer estado;
    
    @ManyToOne
    @JoinColumn(name =  "id", nullable = false)
    private Estudiante estudiante;
    private Sala sala;

  

    

}
