package biblioteca.salas.duoc.controller;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import biblioteca.salas.duoc.service.ReservaService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.Date;
import static org.mockito.Mockito.when;
import biblioteca.salas.duoc.model.Reserva;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//cargar el controlador que se va a simular
@WebMvcTest(ReservaController.class)
public class ReservaControllerTest {

    //se inyecta un mock de reservaservice
    @MockBean
    private ReservaService reservaService;

    //crear un mock proporcionado por spring
    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllReservas_returnsOKAndJson(){
        //crear una reserva ficticia para la respuesta del servicio
        List<Reserva> listaReservas = Arrays.asList(new Reserva(1L, new Date(),new Date(), new Date(), 1, null, null));

        //identificar el comportamiento del servicio
        when(reservaService.findAll()).thenReturn(listaReservas);

        //Ejecutar la funcion del controlador
        //Ejecutar el metodo GET (endpoint)
        //verficar que la respuesta sea 200 OK
        //validar que el archivo json contenga los id
        try{
            mockMvc.perform(get("api/reservas")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(1L));
        }catch(Exception e){

        }
        

    }

}
