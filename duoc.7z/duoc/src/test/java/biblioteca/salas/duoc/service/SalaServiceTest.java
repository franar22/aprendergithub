package biblioteca.salas.duoc.service;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThat;

import biblioteca.salas.duoc.model.Sala;
import biblioteca.salas.duoc.model.TipoSala;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import biblioteca.salas.duoc.repository.SalaRepository;

//habilitamos la extension de mockito
@ExtendWith(MockitoExtension.class)
public class SalaServiceTest {
    //simulo el repositorio de sala
    @Mock
    private SalaRepository repository;

    //genera el mock de inyeccion del servicio
    @InjectMocks
    private SalaService service;

    @Test
    void save_returnsSavedSala(){
        //creamos el objeto de ejemplo
        Sala nuevaSala = new Sala(10L,"Sala 1", 6, 1, new TipoSala(1L,"Estudio"));

        //definir el comportamiento del mock (respositorio)
        when(repository.save(nuevaSala)).thenReturn(nuevaSala);

        //ejecutar el metodo a probar
        Sala result = service.save(nuevaSala);

        //comprueba que devuelven lo mismo
        assertThat(result).isSameAs(nuevaSala);
    }


}
