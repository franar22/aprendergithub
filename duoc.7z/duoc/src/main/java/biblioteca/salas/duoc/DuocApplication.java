package biblioteca.salas.duoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuocApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuocApplication.class, args);
	}

}
