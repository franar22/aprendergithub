package biblioteca.salas.duoc.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "carrera")
@Data
@AllArgsConstructor
@Schema(description = "Tipo de salas disponibles")
@NoArgsConstructor
public class Carrera {
    @Id
    @Schema(description = "id unico de tipo de sala")
    private String codigo;
    @Column(nullable = false)
    private String nombre;

}
